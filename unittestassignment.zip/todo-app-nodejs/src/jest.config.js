// tests/jest.config.js

module.exports = {
    testEnvironment: 'node',
    coverageDirectory: 'coverage',
};
